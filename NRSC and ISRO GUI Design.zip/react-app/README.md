# Lunar Crater Detection — React frontend (NRSC / ISRO)

Standalone **React + Vite** app. Frontend only — image processing is
**simulated in the browser**; no backend is connected yet.

## Run

```bash
cd react-app
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in dist/
```

## Structure

```
react-app/
├─ index.html            # Vite entry
├─ package.json
├─ vite.config.js
├─ public/
│  ├─ ISRO_NRSC_Logo.png # header, left
│  └─ ISRO_Logo.png      # header, right
└─ src/
   ├─ main.jsx           # React root
   ├─ App.jsx            # the whole UI + simulated detector
   └─ industry.css       # Industry design-system tokens & classes
```

## Connecting your backend

All the fake work lives in one function — `runAnalysis()` in `src/App.jsx`.
Replace it with a call to your API and render the response. Sketch:

```jsx
const process = async () => {
  if (!hasImage || processing) return;
  setProcessing(true);
  const blob = await new Promise((r) => inCanvasRef.current.toBlob(r));
  const body = new FormData();
  body.append('image', blob);
  body.append('threshold', threshold);
  body.append('sensitivity', sensitivity);

  const res = await fetch('/api/detect', { method: 'POST', body });
  const data = await res.json();   // { craters:[{x,y,r,confidence,size}], ... }

  drawDetections(data.craters);    // draw onto outCanvasRef
  setResult({ /* map data -> summary + size distribution */ });
  setProcessing(false);
  setDone(true);
};
```

The input canvas already holds the uploaded image at display resolution, so
`toBlob()` gives you a ready-to-POST file. Return crater coordinates/radii in
that same coordinate space and the drawing loop stays as-is.

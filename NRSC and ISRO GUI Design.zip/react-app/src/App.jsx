import React, { useCallback, useRef, useState } from 'react';
import {
  UploadCloud, FileImage, ScanSearch, Loader,
  Scan, Sparkles, RotateCcw, Download,
} from 'lucide-react';

/* ────────────────────────────────────────────────────────────────
   Lunar Crater Detection — frontend only.
   Detection is SIMULATED client-side (canvas). To connect a real
   backend, replace `runAnalysis()` with a fetch() to your API. See README.
   ──────────────────────────────────────────────────────────────── */

const DARK = '#05070a';
const PANEL = 'rgba(13,17,23,0.88)';
const BORDER = '#30363d';

export default function App() {
  const [threshold] = useState(70);
  const [mode, setMode] = useState('regular');
  const [drag, setDrag] = useState(false);
  const [fileName, setFileName] = useState('');
  const [fileMeta, setFileMeta] = useState('');
  const [hasImage, setHasImage] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [done, setDone] = useState(false);

  const fileRef = useRef(null);
  const inCanvasRef = useRef(null);
  const outCanvasRef = useRef(null);

  const openPicker = () => fileRef.current && fileRef.current.click();

  const loadFile = useCallback((f) => {
    const url = URL.createObjectURL(f);
    const img = new Image();
    img.onload = () => {
      const c = inCanvasRef.current;
      const max = 640;
      const scale = Math.min(max / img.width, max / img.height, 1);
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      const o = outCanvasRef.current;
      o.width = 0; o.height = 0;
      setHasImage(true);
      setDone(false);
      setFileName(f.name);
      setFileMeta((f.size / 1024).toFixed(0) + ' KB · ' + img.width + '×' + img.height);
      URL.revokeObjectURL(url);
    };
    img.src = url;
  }, []);

  const onFile = (e) => { const f = e.target.files && e.target.files[0]; if (f) loadFile(f); };
  const onDragOver = (e) => { e.preventDefault(); setDrag(true); };
  const onDragLeave = (e) => { e.preventDefault(); setDrag(false); };
  const onDrop = (e) => {
    e.preventDefault(); setDrag(false);
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f && f.type.startsWith('image')) loadFile(f);
  };

  const process = (m) => {
    if (!hasImage || processing) return;
    setMode(m);
    setProcessing(true);
    setDone(false);
    const t0 = performance.now();
    setTimeout(() => runAnalysis(m, t0), 900);
  };

  /* ── SIMULATED detector — swap for a real API call ── */
  const runAnalysis = (m, _t0) => {
    const src = inCanvasRef.current;
    const out = outCanvasRef.current;
    const w = src.width, h = src.height;
    out.width = w; out.height = h;
    const sctx = src.getContext('2d');
    const octx = out.getContext('2d');
    const enhanced = m === 'enhanced';

    const data = sctx.getImageData(0, 0, w, h);
    const px = data.data;
    for (let i = 0; i < px.length; i += 4) {
      let g = px[i] * 0.299 + px[i + 1] * 0.587 + px[i + 2] * 0.114;
      if (enhanced) g = Math.min(255, Math.max(0, (g - 128) * 1.5 + 128));
      px[i] = px[i + 1] = px[i + 2] = g * 0.94;
    }
    octx.putImageData(data, 0, 0);

    const conf = threshold / 100;
    const count = Math.max(4, Math.round((enhanced ? 12 : 6) * (1.2 - conf * 0.3)));
    let seed = 42 + (enhanced ? 7 : 0);
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    octx.strokeStyle = enhanced ? '#c05a3c' : '#5980a6';
    octx.lineWidth = Math.max(1, w / 300);
    octx.font = Math.max(9, w / 52) + 'px monospace';
    octx.fillStyle = octx.strokeStyle;
    for (let k = 0; k < count; k++) {
      const r = w * ((enhanced ? 0.015 : 0.03) + rnd() * (enhanced ? 0.06 : 0.09));
      const cx = r + rnd() * (w - 2 * r);
      const cy = r + rnd() * (h - 2 * r);
      octx.beginPath(); octx.arc(cx, cy, r, 0, Math.PI * 2); octx.stroke();
      octx.beginPath();
      octx.moveTo(cx - 4, cy); octx.lineTo(cx + 4, cy);
      octx.moveTo(cx, cy - 4); octx.lineTo(cx, cy + 4); octx.stroke();
      octx.fillText('#' + (k + 1), cx - r, cy - r - 3);
    }

    setProcessing(false);
    setDone(true);
  };

  const reset = () => {
    [inCanvasRef, outCanvasRef].forEach((r) => {
      const c = r.current; if (c) { c.width = 0; c.height = 0; }
    });
    setHasImage(false); setDone(false); setProcessing(false);
    setFileName(''); setFileMeta('');
  };

  const download = () => {
    const c = outCanvasRef.current; if (!c) return;
    const a = document.createElement('a');
    a.download = 'crater-detection-output.png';
    a.href = c.toDataURL('image/png');
    a.click();
  };

  const imgBox = {
    position: 'relative', height: 440, border: '1px solid ' + BORDER,
    background: '#161b22', display: 'flex', alignItems: 'center',
    justifyContent: 'center', overflow: 'hidden',
  };
  const panel = {
    position: 'relative', padding: 14, background: PANEL,
    backdropFilter: 'blur(2px)', color: '#e6edf3', border: '1px solid ' + BORDER,
  };
  const btn = {
    position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center',
    gap: 9, minWidth: 190, height: 52, fontSize: 14, letterSpacing: '.6px',
    background: DARK, color: '#e6edf3', border: '1px solid ' + BORDER, cursor: 'pointer',
  };
  const disabled = !hasImage || processing;

  return (
    <div style={{ minHeight: '100vh', background: DARK, color: '#e6edf3', fontFamily: 'var(--font-body)', display: 'flex', flexDirection: 'column' }}>

      {/* ── HEADER ── */}
      <header className="nav" style={{ position: 'relative', zIndex: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 28px', borderBottom: '1px solid var(--color-neutral-300)', background: '#0d1117' }}>
        <img src="/nrsc-logo.png" alt="ISRO / NRSC" style={{ height: 71, width: 126, display: 'block' }} />
        <div style={{ textAlign: 'center', flex: 1, minWidth: 0, padding: '0 16px' }}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 19, letterSpacing: '1.5px', textTransform: 'uppercase', color: '#fff' }}>Lunar Crater Detection Model</div>
          <div style={{ fontSize: 10, letterSpacing: '1px', color: 'var(--color-neutral-400)', textTransform: 'uppercase' }}>An AI-based model for detecting craters on the lunar surface</div>
        </div>
        <img src="/isro-logo.png" alt="ISRO" style={{ height: 102, width: 159, display: 'block' }} />
      </header>

      {/* ── BODY ── */}
      <main style={{ position: 'relative', flex: 1, display: 'flex', flexDirection: 'column', gap: 22, padding: 28, width: '100%', boxSizing: 'border-box', background: DARK }}>
        {/* background image layer + scrim */}
        <div aria-hidden style={{ position: 'fixed', inset: 0, background: "url('/moon-bg.png') center/cover", filter: 'contrast(1.4) brightness(1.05) saturate(1.1)', zIndex: 0 }} />
        <div aria-hidden style={{ position: 'fixed', inset: 0, background: 'rgba(5,7,10,0.35)', zIndex: 0 }} />

        <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', gap: 22, maxWidth: 1500, width: '100%', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>

            {/* INPUT (upload lives here) */}
            <div className="blueprint" style={panel}>
              <Corners />
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <span style={{ fontFamily: 'var(--font-heading)', fontSize: 14, letterSpacing: '1px', textTransform: 'uppercase', color: '#fff' }}>Input</span>
                <span className="tag tag-outline" style={{ fontSize: 10 }}>SOURCE</span>
              </div>
              <div
                onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop} onClick={openPicker}
                style={{ ...imgBox, cursor: 'pointer', ...(drag ? { outline: '2px dashed var(--color-accent)', outlineOffset: -6 } : null) }}>
                <canvas ref={inCanvasRef} style={{ maxWidth: '100%', maxHeight: '100%', display: 'block' }} />
                {!hasImage && (
                  <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, color: '#9aa4b0' }}>
                    <UploadCloud size={44} strokeWidth={1.4} color="var(--color-accent)" />
                    <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 600, fontSize: 17, letterSpacing: '.4px', color: '#e6edf3' }}>Upload Image</div>
                    <div style={{ fontSize: 12 }}>Click to browse or drag &amp; drop · PNG, JPG</div>
                  </div>
                )}
                <input type="file" accept="image/*" ref={fileRef} onChange={onFile} style={{ display: 'none' }} />
              </div>
              {fileName && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, paddingTop: 10, fontSize: 12 }}>
                  <FileImage size={15} strokeWidth={1.5} color="var(--color-accent)" />
                  <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{fileName}</span>
                  <span style={{ color: '#9aa4b0' }}>{fileMeta}</span>
                </div>
              )}
            </div>

            {/* OUTPUT */}
            <div className="blueprint" style={panel}>
              <Corners />
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <span style={{ fontFamily: 'var(--font-heading)', fontSize: 14, letterSpacing: '1px', textTransform: 'uppercase', color: '#fff' }}>Output</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  {done && (
                    <button className="btn btn-secondary" onClick={download} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '5px 11px', fontSize: 11.5 }}>
                      <Download size={13} strokeWidth={1.8} /> Export
                    </button>
                  )}
                  <span className="tag tag-accent" style={{ fontSize: 10 }}>{done ? (mode === 'enhanced' ? 'ENHANCED' : 'REGULAR') : '—'}</span>
                </div>
              </div>
              <div style={imgBox}>
                <canvas ref={outCanvasRef} style={{ maxWidth: '100%', maxHeight: '100%', display: 'block' }} />
                {!processing && !done && (
                  <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, color: '#8b949e' }}>
                    <ScanSearch size={38} strokeWidth={1.4} />
                    <span style={{ fontSize: 12 }}>Awaiting processing</span>
                  </div>
                )}
                {processing && (
                  <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, background: 'rgba(5,7,10,0.78)' }}>
                    <Loader size={32} strokeWidth={1.6} color="var(--color-accent)" style={{ animation: 'lc-spin 1s linear infinite' }} />
                    <span style={{ fontSize: 12, letterSpacing: '.5px', color: 'var(--color-accent-700)' }}>Analyzing…</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ACTION BUTTONS: Regular / Enhanced / Reset */}
          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button className="btn blueprint" onClick={() => process('regular')} disabled={disabled} style={btn}>
              <Corners /><Scan size={18} strokeWidth={1.8} /><span>Regular</span>
            </button>
            <button className="btn blueprint" onClick={() => process('enhanced')} disabled={disabled} style={btn}>
              <Corners /><Sparkles size={18} strokeWidth={1.8} /><span>Enhanced</span>
            </button>
            <button className="btn blueprint" onClick={reset} title="Reset" style={{ ...btn, minWidth: 0, padding: '0 18px' }}>
              <Corners /><RotateCcw size={16} strokeWidth={1.8} /><span>Reset</span>
            </button>
          </div>
        </div>
      </main>

      <footer style={{ position: 'relative', zIndex: 1, padding: '12px 28px', borderTop: '1px solid ' + BORDER, fontSize: 10.5, letterSpacing: '.4px', color: '#8b949e', textAlign: 'center', background: '#0d1117' }}>
        NRSC · ISRO — Frontend demo · Detection simulated client-side (backend not connected)
      </footer>

      <style>{`@keyframes lc-spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

function Corners() {
  return (
    <>
      <i className="corner tl" /><i className="corner tr" /><i className="corner bl" /><i className="corner br" />
    </>
  );
}
